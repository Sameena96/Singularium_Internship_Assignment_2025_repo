# Smart Task Analyzer

## How to Run (Ubuntu)
```
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Frontend:
```
cd frontend
xdg-open index.html
```

API:
```
POST /api/tasks/analyze/?mode=smart
```
