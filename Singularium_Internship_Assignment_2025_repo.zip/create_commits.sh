#!/bin/bash
git init
git add .
git commit -m "initial: project setup"
git commit --allow-empty -m "feat: add scoring algorithm"
git commit --allow-empty -m "feat: implement analyze & suggest endpoints"
git commit --allow-empty -m "feat(frontend): add UI & API integration"
git commit --allow-empty -m "test: add scoring unit tests"
echo "Repository initialized with commit history."
