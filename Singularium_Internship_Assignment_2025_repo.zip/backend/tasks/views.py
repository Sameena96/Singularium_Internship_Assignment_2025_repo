from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import TaskInputSerializer
from .scoring import score

@api_view(['POST'])
def analyze(request):
    mode=request.GET.get("mode","smart")
    tasks=request.data

    for t in tasks:
        ser=TaskInputSerializer(data=t)
        ser.is_valid(raise_exception=True)
        data=ser.validated_data
        t["score"]=score(data, mode)

    tasks=sorted(tasks, key=lambda x:x["score"], reverse=True)
    return Response(tasks)

@api_view(['GET'])
def suggest(request):
    return Response({"message":"Implement logic for dynamic suggestions"})
