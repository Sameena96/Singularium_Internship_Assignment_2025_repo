from django.test import TestCase
from datetime import date, timedelta
from .scoring import score

class ScoringTest(TestCase):
    def test_basic_score(self):
        task={
            "title":"Test",
            "due_date":date.today()+timedelta(days=5),
            "estimated_hours":3,
            "importance":8,
            "dependencies":[]
        }
        s=score(task)
        self.assertTrue(s>0)
