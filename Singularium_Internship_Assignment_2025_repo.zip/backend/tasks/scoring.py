from datetime import date

def score(task, mode="smart"):
    days_left=(task['due_date'] - date.today()).days

    urgency = max(0, 30 - days_left)
    importance=task["importance"]
    effort=10 - task["estimated_hours"]
    deps=len(task.get("dependencies",[]))

    if mode=="fastest":
        return effort*2 + importance*0.5
    if mode=="impact":
        return importance*2 + urgency*0.5
    if mode=="deadline":
        return urgency*2 + importance*0.5

    # Smart balance
    return urgency*0.4 + importance*0.4 + effort*0.1 + deps*0.1
