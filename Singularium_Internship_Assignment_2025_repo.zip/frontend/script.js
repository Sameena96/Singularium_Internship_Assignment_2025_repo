async function analyze(){
 let data=JSON.parse(document.getElementById("jsonInput").value);
 let mode=document.getElementById("mode").value;
 let res=await fetch(`http://127.0.0.1:8000/api/tasks/analyze/?mode=${mode}`,{
   method:"POST",
   headers:{"Content-Type":"application/json"},
   body:JSON.stringify(data)
 });
 let out=await res.json();
 document.getElementById("output").innerHTML=
    '<pre>'+JSON.stringify(out,null,2)+'</pre>';
}